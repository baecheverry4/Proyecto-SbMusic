package sbmusic;

/**
 *
 * @author Hogar
 */
public class Main {
    public static void main(String[] args){
        Sonido viento = new Sonido("Largo", "debil", "agudo");
        System.out.println(viento.toString());
    }
}
